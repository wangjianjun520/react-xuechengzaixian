export default class myorders extends React.Component {
    render() {
         return (<div>
            我的订单页面
        </div>)
    }
}