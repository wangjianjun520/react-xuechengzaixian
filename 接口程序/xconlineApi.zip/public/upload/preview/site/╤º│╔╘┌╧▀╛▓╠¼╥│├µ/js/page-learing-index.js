/****/
// 首页导航左侧导航显隐控制
$(document).scroll(function(){
    var scTop = $(document).scrollTop()
    if($(window).innerWidth() >= 1280){
         if(scTop >= 550 ){
         $(".index-cont-nav,.gotop").show();   
    }else{
         $(".index-cont-nav,.gotop").hide();   
    }   
    }
    
})