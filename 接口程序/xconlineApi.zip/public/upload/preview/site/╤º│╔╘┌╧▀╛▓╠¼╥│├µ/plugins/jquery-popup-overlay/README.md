# jQuery Popup Overlay

jQuery plugin for responsive and accessible modal overlays and tooltips.

## Documentation & demo
[Documentation & demo](http://vast-eng.github.com/jquery-popup-overlay/)

## License
Released under the [MIT license](http://www.opensource.org/licenses/MIT).